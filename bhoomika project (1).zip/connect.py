import pymysql
def connectdb():
    try:
       db=pymysql.connect(host="localhost",user="root",password="",database="goto")
       #print(db)
       return db
    except Exception as e:
        print("error:",e)

       
    

    
   
    
       
            
