'''
deleting record
'''
import connect
try:
    dobj=connect.connectdb()
#print(dobj)
    cu=dobj.cursor()
    
    sql="delete from student where id=2"
    cu.execute(sql)
    
    dobj.commit()
    print("record deleted uccessfully")
   

except Exception as e:
    print("error:",e)
    
    
