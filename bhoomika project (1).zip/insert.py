'''
insert record into database
'''
import connect
try:
    dobj=connect.connectdb()
#print(dobj)
    cu=dobj.cursor()
    sql="insert into student(studentname,studentrollno,percentage)values('nayana','18','50')"
    cu.execute(sql)
    dobj.commit()
    print("record inserted successfully")

except Exception as e:
    print("error:",e)
    
    
    
