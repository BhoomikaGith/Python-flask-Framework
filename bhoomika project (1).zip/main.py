'''
main.py
'''
from flask import*
import pymysql

app=Flask(__name__)
@app.route('/')
def index():
    try:
        db=pymysql.connect(host="localhost",user="root",password="",database="goto")
        cu=db.cursor()
        sql="select * from student"
        cu.execute(sql)
        data=cu.fetchall()

        
    
        return render_template('index.html',d=data)
    
    except Exception as e:
        print("error:",e)
    
     

        
@app.route('/student')
def form():
    return render_template('form.html')


@app.route('/store',methods=['POST','GET'])
def store():
    sn=request.form['studentname']
    sr=request.form['studentrollno']
    per=request.form['percentage']
    try:
        db=pymysql.connect(host="localhost",user="root",password="",database="goto")
        cu=db.cursor()

        sql="insert into student(studentname,studentrollno,percentage)values('{}','{}','{}')".format(sn,sr,per)
        cu.execute(sql)
        db.commit()
        return redirect('/')
       # return "record inserted successfull"

    
    except Exception as e:
        print("error:",e)

@app.route('/delete/<rid>')
def delete(rid):
    try:
        db=pymysql.connect(host="localhost",user="root",password="",database="goto")
        cu=db.cursor()
        sql="delete from student where id={}".format(rid)
        cu.execute(sql)
        db.commit()
        return redirect('/')
    except Exception as e:
        print("error:",e)


@app.route('/edit/<rid>')
def edit(rid):

    try:
        db=pymysql.connect(host="localhost",user="root",password="",database="goto")
        cu=db.cursor()
        sql="select * from student where id={}".format(rid)
        cu.execute(sql)
        data=cu.fetchone()
        return render_template('editform.html',d=data)


    except Exception as e:
        print("error:",e)
 

   
       
       



    

@app.route('/update/<rid>',methods=['POST','GET'])
def update(rid):
    sn=request.form['studentname']
    sr=request.form['studentrollno']
    per=request.form['percentage']

    try:
        db=pymysql.connect(host="localhost",user="root",password="",database="goto")
        cu=db.cursor()
        sql="update student SET studentname='{}',studentrollno='{}',percentage='{}' where id='{}'".format(sn,sr,per,rid)
        cu.execute(sql)
        db.commit()
        return redirect('/')


    except Exception as e:
        print("error:",e)
    
   
    
    
   





app.run(debug=True)
