'''
selecting record
'''


import connect
try:
    dobj=connect.connectdb()
#print(dobj)
    cu=dobj.cursor()
    #sql="select * from student"
    sql="select * from student where id=2"
    cu.execute(sql)
    #data=cu.fetchall()
    data=cu.fetchone()
    print("record are:")
    print(data)

except Exception as e:
    print("error:",e)
    
    
    
