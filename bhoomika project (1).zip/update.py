'''
updating record
'''



import connect
try:
    dobj=connect.connectdb()
#print(dobj)
    cu=dobj.cursor()
    
    sql="update student SET studentname='nithya',studentrollno='32' where id=3"
    cu.execute(sql)
    
    dobj.commit()
    print("record updates successfully")
   

except Exception as e:
    print("error:",e)
    
    
